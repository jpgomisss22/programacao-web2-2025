const express = require('express');
const axios = require('axios');

const app = express();
const PORT = 6969;

// Rota que busca o Piplup na API do Pokémon
app.get('/pokemon/piplup', async (req, res) => {
    try {
        const response = await axios.get('https://pokeapi.co/api/v2/pokemon/piplup');
        res.json(response.data); // Retorna os dados da API
    } catch (error) {
        res.status(500).json({ error: 'Erro ao buscar dados' });
    }
});

// Outra rota de exemplo
app.get('/gay', (req, res) => {
    res.send('abilities');
});

// Iniciar o servidor
app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});
